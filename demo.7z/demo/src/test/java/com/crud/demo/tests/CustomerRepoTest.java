package com.crud.demo.tests;

public class CustomerRepoTest {

}
