package com.crud.demo;

import static org.junit.Assert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.crud.demo.controller.CustomerController;

@SpringBootTest
class TatademoApplicationTests {

//  @Autowired
//  private CustomerController custController;
	@Test
	void contextLoads() {
//	 assertEquals(custController,);
	}

}
