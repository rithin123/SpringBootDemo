package com.crud.demo.utility;

public class CustomerDto {

}
