package com.crud.demo.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crud.demo.model.UserDomain;

public interface UserRepository extends JpaRepository<UserDomain, Integer>{
	
	 Optional<UserDomain> findByName(String username);
	

}
